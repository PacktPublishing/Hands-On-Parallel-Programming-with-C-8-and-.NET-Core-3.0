﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        static Dictionary<string, int> _concurrent = new Dictionary<string, int>();

        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // creating tasks
            var task1 = Task.Run(() => WriteToDictionary());
            var task2 = Task.Run(() => WriteToDictionary());


            // awaiting for tasks to execute
            Task.WaitAll(task1, task2);

            // looking at average number of values
            Console.WriteLine($"Average: {_concurrent.Values.Average()}");


            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

        private static void WriteToDictionary()
        {
            for (int num = 0; num < 999; num++)
            {
                _concurrent.Add(num.ToString(), num);
            }
        }

    }
}