﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        static Dictionary<string, int> _concurrent = new Dictionary<string, int>();

        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // Creating a concurrent bag and adding values to it
            var bag = new ConcurrentBag<int>();
            bag.Add(1);
            bag.Add(2);
            bag.Add(3);

            int result;
            // Getting last added element
            if (bag.TryPeek(out result))
            {
                Console.WriteLine($"TryPeek result: {result}");
            }

            // Getting and removing last added element
            if (bag.TryTake(out result))
            {
                Console.WriteLine($"TryTake result: {result}");
            }

            Console.WriteLine($"final bag content: {string.Join(", ", bag.ToArray())}");

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

    }
}