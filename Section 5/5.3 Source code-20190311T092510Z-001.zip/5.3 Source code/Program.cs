﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        static Dictionary<string, int> _concurrent = new Dictionary<string, int>();

        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // Create ConcurrentStack from array of elements.
            int[] elements = { 50, 10, 0 };
            var stack = new ConcurrentStack<int>(elements);

            Console.WriteLine(string.Join(",", stack.ToArray()));

            // Push a new value to the stack.
            stack.Push(100);

            Console.WriteLine(string.Join(",", stack.ToArray()));

            // Use TryPeek to get top of the stack.
            if (stack.TryPeek(out int resultPeek))
            {
                Console.WriteLine($"TryPeek result: {resultPeek}");
            }

            // Use TryPop to get and remove top of the stack.
            if (stack.TryPop(out int resultPop))
            {
                Console.WriteLine($"TryPop result: {resultPop}");
            }

            Console.WriteLine(string.Join(",", stack.ToArray()));

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

    }
}