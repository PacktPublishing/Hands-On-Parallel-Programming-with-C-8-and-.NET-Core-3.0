﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // Creating a task and adding a continuation to it
            var task1 = Task.Run(() => throw new CustomException("This exception is expected!"))
                .ContinueWith(t =>
                {
                    Console.WriteLine($"{t.Exception.InnerException.GetType().Name} : {t.Exception.InnerException.Message}");
                }, TaskContinuationOptions.OnlyOnFaulted);

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

    }

    public class CustomException : Exception
    {
        public CustomException(string message) : base(message) { }

        public CustomException() : base()
        {
        }

        public CustomException(string message, Exception innerException) : base(message, innerException)
        {
        }
    }
}