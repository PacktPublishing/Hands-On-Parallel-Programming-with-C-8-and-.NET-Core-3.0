﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // Creating enumerable range
            var nums = Enumerable.Range(10, 10000);
            var query = nums.AsParallel().Where(n => n % 10 == 0).Select(n => n);

            // Process the results and add them to a Concurrent Bag
            // which safely accepts concurrent add operation
            var cb = new ConcurrentBag<int>();
            query.ForAll(e => cb.Add(e));

            // Output all data from Concurrent Bag to console
            Console.WriteLine(String.Join(", ", cb));

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }
    }
}