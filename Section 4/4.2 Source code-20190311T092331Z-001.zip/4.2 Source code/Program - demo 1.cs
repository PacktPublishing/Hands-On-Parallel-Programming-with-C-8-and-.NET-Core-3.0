﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        public static int counter;
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // Creating enumerable range
            var source = Enumerable.Range(1, 1000000);
            var sw = new Stopwatch();
            sw.Start();

            // Calculating even numbers
            var evenNumbers = source.AsParallel().Where(num => num % 2 == 0).Select(num => num);
            sw.Stop();

            Console.WriteLine($"{evenNumbers.Count()}, even numbers out of {source.Count()}, in: {sw.ElapsedMilliseconds}");

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }
    }
}