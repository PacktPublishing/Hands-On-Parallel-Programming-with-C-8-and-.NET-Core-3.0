﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            var source = new List<City>
                    {
                        new City("Amsterdam", 1236),
                        new City("Berlin", 65236),
                        new City("Boston", 68921),
                        new City("Chongqing", 31236),
                        new City("Dublin", 736),
                        new City("Lisbon", 1436),
                        new City("London", 41236),
                        new City("Madrid", 41436),
                        new City("Miami", 81236),
                        new City("New York", 41236),
                        new City("OPorto", 41236),
                    };

            var cityNames = source.AsParallel().AsOrdered()
                .Where(city => city.Population > 10000).Select(city => city.Name);

            foreach (var city in cityNames)
            {
                Console.WriteLine(city);
            }

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }
    }

    internal class City
    {
        public City(string name, int population)
        {
            Name = name;
            Population = population;
        }

        public string Name { get; set; }
        public int Population { get; set; }
    }
}