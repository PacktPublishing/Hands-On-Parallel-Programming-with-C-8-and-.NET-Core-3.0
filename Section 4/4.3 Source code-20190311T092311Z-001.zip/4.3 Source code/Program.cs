﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // creating a data
            var source = Enumerable.Range(0, 3000000);

            // creating a potential parallel query
            var queryToMeasure = source.Where(n => n % 3 == 0).Select(n => n);

            Console.WriteLine("Measuring...");

            var sw = Stopwatch.StartNew();

            // For pure query cost, enumerate and do nothing else
            foreach (var n in queryToMeasure) { }

            sw.Stop();
            Console.WriteLine($"Total query time: {sw.ElapsedMilliseconds} ms");

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

    }
}