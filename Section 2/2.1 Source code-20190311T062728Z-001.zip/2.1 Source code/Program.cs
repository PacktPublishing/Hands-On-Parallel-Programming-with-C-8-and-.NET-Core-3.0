﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            var task = Task.Run(() => Operation1());
            Console.WriteLine("this is executed first");
            task.Wait();

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

        private static void Operation1()
        {
            Console.WriteLine("Operation 1 executed");
        }

        private static void Operation2()
        {
            Console.WriteLine("Operation 2 executed");
        }
    }
}