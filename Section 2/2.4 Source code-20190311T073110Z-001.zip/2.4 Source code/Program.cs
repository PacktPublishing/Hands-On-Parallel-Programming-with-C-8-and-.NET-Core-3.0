﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // Represents async code
            Run();

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

        private static async void Run()
        {
            // Creating new task
            var t1 = Task<string>.Run(() => {
                Thread.Sleep(2000);
                return "t1 executed";
            });

            // Grabbing task result
            var taskResult = await t1;
            Console.WriteLine(taskResult);
        }

    }
}