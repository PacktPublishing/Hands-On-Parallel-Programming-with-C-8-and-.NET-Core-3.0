﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // Invoking continue with
            ContinueWithOperation();

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

        private static void ContinueWithOperation()
        {
            // Creating a task and adding continuation
            var t = Task<string>.Run(() => LongRunningOperation("Continue With", 500));

            // Adding continuation
            t.ContinueWith((task1) => {
                Console.WriteLine(task1.Result);
            });

        }

        private static string LongRunningOperation(string s, int sec)
        {
            Thread.Sleep(sec);
            return $"{s} Completed";
        }

    }
}