﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelSearch
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            if (args == null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            Console.WriteLine("*** Start Main ***");

            // Creates 3 different tasks
            Task[] tasks = new Task[3]
            {
                Task.Factory.StartNew(() => Method1()),
                Task.Factory.StartNew(() => Method2()),
                Task.Factory.StartNew(() => Method3()),
            };

            // Blocks main thread
            Task.WaitAll(tasks);

            // Continue on this thread...

            Console.WriteLine("*** End Main ***");
            Console.ReadKey();
        }

        private static void Method1()
        {
            Thread.Sleep(2000);
            Console.WriteLine("Method1");
        }

        private static void Method2()
        {
            Console.WriteLine("Method2");
        }

        private static void Method3()
        {
            Console.WriteLine("Method3");
        }

    }
}